# Chat System Pro 快速部署指南

## 快速开始

### 1. 环境要求

- Docker 20.10+
- Docker Compose 2.0+
- 2核CPU, 4GB内存, 50GB磁盘

### 2. 快速部署

```bash
# 解压文件
tar -xzf chat-system-pro-v1.0.0-xxxxxxxx.tar.gz
cd chat-system-pro-v1.0.0-xxxxxxxx

# 配置环境变量
cp .env.example .env
# 编辑 .env 文件

# 启动服务
docker compose up -d

# 查看状态
docker compose ps

# 访问系统
# 前端: http://localhost
# API: http://localhost:8080
```

### 3. 详细文档

- 安装文档: INSTALL.md
- API文档: API.md
- 功能说明: FEATURES.md
- 部署文档: DEPLOY.md

### 4. 常见问题

Q: Docker启动失败？
A: 确保Docker Desktop已启动，或运行 `sudo systemctl start docker`

Q: 数据库连接失败？
A: 等待MySQL初始化完成，约30秒后重试

Q: 如何修改端口？
A: 编辑 docker-compose.yml 中的端口映射

Q: 如何备份数据？
A: 参考 INSTALL.md 中的数据备份章节

### 5. 获取帮助

- 查看详细文档
- 提交Issue: https://github.com/yourrepo/issues
- 邮箱支持: support@example.com

## 默认账号

- 管理员: admin / admin123 (首次登录后请修改)
- 测试用户: test / test123

## 技术支持

商业支持请联系: business@example.com
